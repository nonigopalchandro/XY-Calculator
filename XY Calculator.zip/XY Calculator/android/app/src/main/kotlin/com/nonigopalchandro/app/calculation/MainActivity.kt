package com.nonigopalchandro.app.calculation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
